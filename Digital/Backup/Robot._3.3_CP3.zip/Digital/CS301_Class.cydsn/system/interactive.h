#include <cytypes.h>
#include <stdbool.h>
    
void led_set(uint8_t state);

bool btn_get();

bool dipsw_get(uint8_t s);

