#include <cytypes.h>
#include <stdbool.h>
    
void led_set(uint8_t state);

bool btn_get();

uint8_t dipsw_get();

